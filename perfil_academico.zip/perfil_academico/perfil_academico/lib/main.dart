import 'package:flutter/material.dart';

void main() {
  runApp(const MeuAplicativo());
}

class MeuAplicativo extends StatelessWidget {
  const MeuAplicativo({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Perfil Acadêmico',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 255, 0, 0),
        ),
        useMaterial3: true,
      ),
      home: const PaginaPerfil(),
    );
  }
}

class PaginaPerfil extends StatelessWidget {
  const PaginaPerfil({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil acadêmico'),
      ),
      // Etapa 6: rolagem, espaçamento, centralização e limite de largura
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: Container(
              constraints: const BoxConstraints(maxWidth: 720),
              // Etapas 7 e 8: Column com hierarquia tipográfica
              // (sem const na Column, pois usa Theme.of(context))
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const CircleAvatar(
                    radius: 52,
                    child: Icon(Icons.analytics, size: 58),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Arthur Thomazoni',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Análise e Desenvolvimento de Sistemas',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),

                  // Etapa 9: seção Sobre mim
                  const SizedBox(height: 24),
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Sobre mim',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Estudante interessado em desenvolvimento de '
                            'aplicações multiplataforma e engenharia de software.',
                            style: TextStyle(fontSize: 16, height: 1.5),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Etapa 11 + 13: Row com Expanded e terceiro card
                  const SizedBox(height: 16),
                  const Row(
                    children: [
                      Expanded(
                        child: InformacaoCard(
                          icone: Icons.school,
                          titulo: 'Período',
                          valor: '4º período',
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: InformacaoCard(
                          icone: Icons.code,
                          titulo: 'Tecnologia',
                          valor: 'Flutter',
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: InformacaoCard(
                          icone: Icons.psychology,
                          titulo: 'Competência',
                          valor: 'Resolução de problemas',
                        ),
                      ),
                    ],
                  ),

                  // Etapa 12: botão desabilitado
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: null,
                    icon: const Icon(Icons.mail_outline),
                    label: const Text('Entrar em contato'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Etapa 10: widget reutilizável
class InformacaoCard extends StatelessWidget {
  const InformacaoCard({
    required this.icone,
    required this.titulo,
    required this.valor,
    super.key,
  });

  final IconData icone;
  final String titulo;
  final String valor;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icone, size: 30),
            const SizedBox(height: 8),
            Text(
              titulo,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(valor, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}